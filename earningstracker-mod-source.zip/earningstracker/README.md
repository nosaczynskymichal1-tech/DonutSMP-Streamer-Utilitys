# DonutSMP Streamer Utilitys (Fabric, client-side)

## Building from a phone, no PC needed

1. On your phone, extract this zip with any file manager app that supports
   "Extract" (most do, or install a free one like ZArchiver on Android).
2. Make a free account at github.com in your phone browser.
3. Create a new repository (the "+" icon -> "New repository"). Any name.
4. Open the new repo, tap "Add file" -> "Upload files", and drag/select
   every extracted file and folder in (make sure the `.github` folder,
   which is hidden by default on some file managers, comes along too).
   Commit the upload.
5. Go to the repo's **Actions** tab. A workflow run should start
   automatically within a minute (it's set up to build on every push).
6. Tap into that run, wait for the green checkmark (a couple of minutes),
   then scroll down to **Artifacts** and tap
   `donutsmp-streamer-utilitys` to download the built `.jar` straight to
   your phone.
7. Move that `.jar` into Minecraft's `mods` folder (on Android via a file
   manager; on iOS, Minecraft Java Edition isn't available on mobile at
   all, so this only works if you're actually running Java Edition on
   Android/PC/Mac/Linux).

If step 5 shows a red X instead, tap in to see the error log and send me
a screenshot — most likely cause is a version number in
`gradle.properties` that's slightly off for 1.21.11, which is a one-line
fix.


HUD overlay that tracks stream earnings/auction activity from chat, with
keybinds to pay back a payer (1x or 2x) or donate a fixed amount to a target
player. Client-side only — no server install needed.

## Targeted version

Minecraft **1.21.11**, Fabric Loader, Fabric API. If `./gradlew build` fails
on the Yarn mappings or Fabric API version, open
https://fabricmc.net/develop/ , find the exact current build numbers for
1.21.11, and update `yarn_mappings` / `fabric_version` in `gradle.properties`
to match — Fabric publishes new mapping builds often and this project was
written without live internet access to confirm the exact numbers.

## Building

Requires a JDK 21 and internet access (Gradle downloads Minecraft,
mappings, and Fabric API on first run):

```
./gradlew build
```

The finished mod jar is written to `build/libs/earningstracker-1.0.0.jar`.

## Installing

1. Install Fabric Loader for Minecraft 1.21.11.
2. Install Fabric API for the same version into your `mods` folder.
3. Drop the built jar into `mods` too.
4. (Optional) Install Mod Menu for a settings screen in the Mods list.
5. Launch, join a world, press **Right Shift** to open settings.

## Keybinds (set these in Controls -> Earnings Tracker)

All three keybinds default to **unbound** — you pick the keys in Controls.

- **Pay back (1x)** — runs `/pay <last payer> <amount they paid>`
- **Pay back 2x** — runs `/pay <last payer> <amount they paid * 2>`
- **Donate to creator** — runs `/pay <donateTarget> <donateAmount>` (edit
  both in Settings; defaults are in `earningstracker.json`)

Only the player who actually sent the triggering payment (parsed live from
chat each time) is ever paid by the 1x/2x actions — there's no fixed
third-party recipient for those two.

**Heads up on binding Donate to `T`:** `T` is vanilla Minecraft's default
"open chat" key. If you bind Donate to `T`, you'll lose the ability to open
chat with `T` unless you first rebind vanilla's "Open Chat" to a different
key in Controls.

## Chat parsing

Patterns live in `earningstracker.json` (in your `.minecraft/config`
folder) as `paymentRegex` and `auctionRegex`. The defaults expect lines like:

```
Notch paid you 1,250
You won an auction for 3.5M
```

Paste your server's actual wording into the regex if it differs — I didn't
have your exact chat lines to tune against, so treat these as a starting
point, not a guarantee they'll match your server on the first try.

## Safety limits

- `maxPayoutPerAction` — hard cap per button press (default 1B)
- `cooldownSeconds` — minimum gap between actions (default 5s)

These exist because a scripted or spoofed chat line could otherwise prefill
an oversized payout; you still have to press the key yourself for anything
to send.
