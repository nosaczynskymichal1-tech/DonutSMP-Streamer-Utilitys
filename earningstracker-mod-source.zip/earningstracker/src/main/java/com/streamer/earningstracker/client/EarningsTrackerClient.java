package com.streamer.earningstracker.client;

import com.mojang.blaze3d.platform.InputUtil;
import com.streamer.earningstracker.client.config.ModConfig;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil.Type;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

/**
 * Client-side only. Everything below runs locally in your own game client;
 * it never touches the server beyond the /pay commands you explicitly fire,
 * and no installation is required on the server.
 */
public class EarningsTrackerClient implements ClientModInitializer {
	public static ModConfig CONFIG;
	public static HistoryManager HISTORY;

	private final ChatParser parser = new ChatParser();
	private final PayoutManager payouts = new PayoutManager();
	private volatile PendingPayment pending; // most recent unclaimed payment

	private KeyBinding paybackKey;
	private KeyBinding doubleKey;
	private KeyBinding donateKey;
	private KeyBinding settingsKey;

	@Override
	public void onInitializeClient() {
		CONFIG = ModConfig.load();
		HISTORY = new HistoryManager();

		paybackKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.earningstracker.payback", Type.KEYSYM, InputUtil.UNKNOWN_KEY.getCode(), "category.earningstracker"));
		doubleKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.earningstracker.doublepay", Type.KEYSYM, InputUtil.UNKNOWN_KEY.getCode(), "category.earningstracker"));
		// Defaults to T. NOTE: T is vanilla's default "Open Chat" key — if you
		// keep this default, rebind vanilla's "Open Chat" to C (or anything else)
		// in Controls, or the two will fight over the same key.
		donateKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.earningstracker.donate", Type.KEYSYM, GLFW.GLFW_KEY_T, "category.earningstracker"));
		settingsKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
				"key.earningstracker.settings", Type.KEYSYM, GLFW.GLFW_KEY_RIGHT_SHIFT, "category.earningstracker"));

		// Listen to all incoming chat/game messages client-side.
		ClientReceiveMessageEvents.ALLOW_GAME.register((message, overlay) -> {
			handleChatLine(message.getString());
			return true; // never swallow the message, just observe it
		});
		ClientReceiveMessageEvents.ALLOW_CHAT.register((message, signedMessage, sender, params, receptionTimestamp) -> {
			handleChatLine(message.getString());
			return true;
		});

		HudRenderCallback.EVENT.register((context, tickDelta) -> HudOverlay.render(context, pending, HISTORY, CONFIG));

		ClientTickEvents.END_CLIENT_TICK.register(client -> {
			while (paybackKey.wasPressed()) onPayback(1.0);
			while (doubleKey.wasPressed()) onPayback(2.0);
			while (donateKey.wasPressed()) onDonate();
			while (settingsKey.wasPressed()) {
				if (client.currentScreen == null) {
					client.setScreen(new com.streamer.earningstracker.client.config.SettingsScreen(null));
				}
			}
		});
	}

	private void handleChatLine(String line) {
		PendingPayment payment = parser.tryParsePayment(line, CONFIG);
		if (payment != null) {
			pending = payment;
			HISTORY.record("payment", payment.player(), payment.amount());
			return;
		}
		Double auctionAmount = parser.tryParseAuction(line, CONFIG);
		if (auctionAmount != null) {
			HISTORY.record("auction", "auction house", auctionAmount);
		}
	}

	private void onPayback(double multiplier) {
		if (pending == null || pending.isStale(10 * 60 * 1000L)) {
			notify("No recent payment to pay back.");
			return;
		}
		PayoutManager.Result result = payouts.payback(pending, CONFIG, multiplier);
		switch (result) {
			case OK -> {
				HISTORY.record(multiplier == 2.0 ? "2x" : "payback", pending.player(), pending.amount() * multiplier);
				pending = null;
			}
			case ON_COOLDOWN -> notify("Still on cooldown, try again in a moment.");
			case OVER_CAP -> notify("That payout is above your configured cap.");
			case NO_PENDING_PLAYER -> notify("No recent payment to pay back.");
		}
	}

	private void onDonate() {
		PayoutManager.Result result = payouts.donate(CONFIG);
		switch (result) {
			case OK -> HISTORY.record("donate", CONFIG.donateTarget, CONFIG.donateAmount);
			case ON_COOLDOWN -> notify("Still on cooldown, try again in a moment.");
			case OVER_CAP -> notify("Donate amount is above your configured cap.");
			default -> {}
		}
	}

	private void notify(String msg) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player != null) {
			client.player.sendMessage(Text.literal("§7[EarningsTracker] §f" + msg), false);
		}
	}
}
