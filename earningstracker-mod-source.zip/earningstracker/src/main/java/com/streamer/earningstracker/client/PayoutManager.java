package com.streamer.earningstracker.client;

import com.streamer.earningstracker.client.config.ModConfig;
import net.minecraft.client.MinecraftClient;
import net.minecraft.text.Text;

/**
 * Sends the actual /pay commands. Every action here requires an explicit
 * button press from the stream operator - nothing fires automatically off
 * a chat message by itself. A cap and cooldown guard against a spoofed or
 * malicious chat line being used to trigger an oversized payout.
 */
public class PayoutManager {
	private long lastActionMillis = 0L;

	public enum Result { OK, ON_COOLDOWN, OVER_CAP, NO_PENDING_PLAYER }

	public Result payback(PendingPayment pending, ModConfig config, double multiplier) {
		if (pending == null) return Result.NO_PENDING_PLAYER;
		double amount = pending.amount() * multiplier;
		return send(pending.player(), amount, config);
	}

	public Result donate(ModConfig config) {
		return send(config.donateTarget, config.donateAmount, config);
	}

	private Result send(String target, double amount, ModConfig config) {
		long now = System.currentTimeMillis();
		if (now - lastActionMillis < config.cooldownSeconds * 1000L) {
			return Result.ON_COOLDOWN;
		}
		if (amount > config.maxPayoutPerAction) {
			return Result.OVER_CAP;
		}
		lastActionMillis = now;
		runPayCommand(target, amount);
		return Result.OK;
	}

	private void runPayCommand(String target, double amount) {
		MinecraftClient client = MinecraftClient.getInstance();
		if (client.player == null) return;
		// Whole-number amounts send without decimals; most economy plugins expect an integer.
		long rounded = Math.round(amount);
		String command = "pay " + target + " " + rounded;
		client.player.networkHandler.sendChatCommand(command);
		client.player.sendMessage(Text.literal("§7[EarningsTracker] §fRan: §e/" + command), false);
	}
}
