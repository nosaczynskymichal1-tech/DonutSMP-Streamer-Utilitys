package com.streamer.earningstracker.client;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Instant;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

/** Appends session totals to a JSON history file so past streams can be reviewed later. */
public class HistoryManager {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("earningstracker_history.json");
	private static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm");

	public static class Entry {
		public String timestamp;
		public String type; // "payment", "auction", "payback", "2x", "donate"
		public String counterparty;
		public double amount;

		public Entry(String type, String counterparty, double amount) {
			this.timestamp = STAMP.withZone(ZoneId.systemDefault()).format(Instant.now());
			this.type = type;
			this.counterparty = counterparty;
			this.amount = amount;
		}
	}

	private List<Entry> entries;

	public HistoryManager() {
		entries = load();
	}

	public void record(String type, String counterparty, double amount) {
		entries.add(new Entry(type, counterparty, amount));
		save();
	}

	public List<Entry> recent(int count) {
		int from = Math.max(0, entries.size() - count);
		return new ArrayList<>(entries.subList(from, entries.size()));
	}

	public double sessionTotal() {
		// "Session" = everything logged since this file was last cleared; wire a
		// clear button into the settings screen if you want a per-stream reset.
		double total = 0;
		for (Entry e : entries) {
			if (e.type.equals("payment") || e.type.equals("auction")) total += e.amount;
		}
		return total;
	}

	private List<Entry> load() {
		if (Files.exists(PATH)) {
			try {
				String json = Files.readString(PATH, StandardCharsets.UTF_8);
				Entry[] arr = GSON.fromJson(json, Entry[].class);
				if (arr != null) {
					List<Entry> list = new ArrayList<>();
					for (Entry e : arr) list.add(e);
					return list;
				}
			} catch (IOException | RuntimeException ignored) {
			}
		}
		return new ArrayList<>();
	}

	private void save() {
		try {
			Files.createDirectories(PATH.getParent());
			Files.writeString(PATH, GSON.toJson(entries), StandardCharsets.UTF_8);
		} catch (IOException ignored) {
		}
	}
}
