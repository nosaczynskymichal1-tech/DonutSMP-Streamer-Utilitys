package com.streamer.earningstracker.client.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;

/**
 * Settings saved to .minecraft/config/earningstracker.json
 * Edit the regex patterns here if your server's chat wording differs.
 */
public class ModConfig {
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
	private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("earningstracker.json");

	// --- Chat parsing ---
	// Matches "<player> paid you <amount>" with an optional unit suffix (k/M/B).
	public String paymentRegex = "^(?<player>[A-Za-z0-9_.]+) paid you \\$?(?<amount>[0-9][0-9,.]*[kKmMbB]?)$";
	// Matches typical auction-house win/sale broadcast lines. Adjust to your server.
	public String auctionRegex = "^(?:You (?:won|sold) .* for \\$?(?<amount>[0-9][0-9,.]*[kKmMbB]?))$";

	// --- Payout behaviour ---
	// Fixed recipient for the Donate button only. Payback/2x always pay whoever
	// actually sent the triggering payment, parsed live from chat each time.
	public String donateTarget = "hejsoytalt";
	public double donateAmount = 500_000_000d;

	// Safety limits on the Payback/2x auto-fill (you still have to press the button).
	public double maxPayoutPerAction = 1_000_000_000d;
	public int cooldownSeconds = 5;

	// --- HUD ---
	public double goalAmount = 0d; // 0 = goal bar hidden
	public int overlayX = 10;
	public int overlayY = 10;
	public boolean showAuctionFeed = true;

	// --- Keybinds are registered in EarningsTrackerClient; nothing to store here ---

	public static ModConfig load() {
		if (Files.exists(PATH)) {
			try {
				String json = Files.readString(PATH, StandardCharsets.UTF_8);
				ModConfig cfg = GSON.fromJson(json, ModConfig.class);
				if (cfg != null) return cfg;
			} catch (IOException | RuntimeException ignored) {
				// fall through to defaults on any parse/read error
			}
		}
		return new ModConfig();
	}

	public void save() {
		try {
			Files.createDirectories(PATH.getParent());
			Files.writeString(PATH, GSON.toJson(this), StandardCharsets.UTF_8);
		} catch (IOException ignored) {
			// non-fatal; settings just won't persist this run
		}
	}
}
