package com.streamer.earningstracker.client;

/** The most recent incoming payment, parsed from chat, waiting on a button press. */
public record PendingPayment(String player, double amount, long receivedAtMillis) {
	public boolean isStale(long maxAgeMillis) {
		return System.currentTimeMillis() - receivedAtMillis > maxAgeMillis;
	}
}
