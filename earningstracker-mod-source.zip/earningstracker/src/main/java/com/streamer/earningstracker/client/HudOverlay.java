package com.streamer.earningstracker.client;

import com.streamer.earningstracker.client.config.ModConfig;
import net.minecraft.client.gui.DrawContext;

import java.util.List;

/** Draws the always-on overlay box: session total, goal bar, pending payment, recent activity. */
public final class HudOverlay {
	private HudOverlay() {}

	public static void render(DrawContext context, PendingPayment pending, HistoryManager history, ModConfig config) {
		int x = config.overlayX;
		int y = config.overlayY;
		int width = 220;
		int lineHeight = 11;
		int lines = 2; // title + total
		if (config.goalAmount > 0) lines++;
		if (pending != null && !pending.isStale(10 * 60 * 1000L)) lines++;
		List<HistoryManager.Entry> recent = config.showAuctionFeed ? history.recent(3) : List.of();
		lines += recent.size();

		int height = lines * lineHeight + 6;
		context.fill(x, y, x + width, y + height, 0x90000000);

		int textY = y + 4;
		context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
				"§6§lEarnings Tracker", x + 6, textY, 0xFFFFFF, true);
		textY += lineHeight;

		double total = history.sessionTotal();
		context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
				"§fSession total: §a" + AmountUtil.format(total), x + 6, textY, 0xFFFFFF, true);
		textY += lineHeight;

		if (config.goalAmount > 0) {
			double pct = Math.min(1.0, total / config.goalAmount);
			String bar = buildBar(pct, 16);
			context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
					"§7Goal: " + bar + " §7" + Math.round(pct * 100) + "%", x + 6, textY, 0xFFFFFF, true);
			textY += lineHeight;
		}

		if (pending != null && !pending.isStale(10 * 60 * 1000L)) {
			context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
					"§ePending: " + pending.player() + " paid " + AmountUtil.format(pending.amount()),
					x + 6, textY, 0xFFFFFF, true);
			textY += lineHeight;
		}

		for (HistoryManager.Entry e : recent) {
			context.drawText(net.minecraft.client.MinecraftClient.getInstance().textRenderer,
					"§8" + e.timestamp.substring(11) + " §7" + e.type + " " + AmountUtil.format(e.amount),
					x + 6, textY, 0xFFFFFF, true);
			textY += lineHeight;
		}
	}

	private static String buildBar(double pct, int segments) {
		int filled = (int) Math.round(pct * segments);
		StringBuilder sb = new StringBuilder("§a");
		for (int i = 0; i < segments; i++) {
			if (i == filled) sb.append("§7");
			sb.append(i < filled ? '|' : '.');
		}
		return sb.toString();
	}
}
