package com.streamer.earningstracker.client;

/** Parses/formats numbers like "1,250", "2.5k", "3M" used in server chat and balances. */
public final class AmountUtil {
	private AmountUtil() {}

	public static double parse(String raw) {
		if (raw == null || raw.isEmpty()) return 0d;
		String s = raw.trim().replace(",", "");
		char suffix = Character.toLowerCase(s.charAt(s.length() - 1));
		double multiplier = 1d;
		if (suffix == 'k') { multiplier = 1_000d; s = s.substring(0, s.length() - 1); }
		else if (suffix == 'm') { multiplier = 1_000_000d; s = s.substring(0, s.length() - 1); }
		else if (suffix == 'b') { multiplier = 1_000_000_000d; s = s.substring(0, s.length() - 1); }
		try {
			return Double.parseDouble(s) * multiplier;
		} catch (NumberFormatException e) {
			return 0d;
		}
	}

	public static String format(double amount) {
		double abs = Math.abs(amount);
		if (abs >= 1_000_000_000d) return trim(amount / 1_000_000_000d) + "B";
		if (abs >= 1_000_000d) return trim(amount / 1_000_000d) + "M";
		if (abs >= 1_000d) return trim(amount / 1_000d) + "k";
		return trim(amount);
	}

	private static String trim(double v) {
		if (v == Math.floor(v)) return String.valueOf((long) v);
		return String.format("%.2f", v);
	}
}
