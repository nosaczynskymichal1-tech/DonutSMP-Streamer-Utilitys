package com.streamer.earningstracker.client;

import com.streamer.earningstracker.client.config.ModConfig;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Turns raw chat lines into payment/auction events using the configurable regexes. */
public class ChatParser {
	private Pattern paymentPattern;
	private Pattern auctionPattern;
	private String compiledFromPaymentRegex;
	private String compiledFromAuctionRegex;

	public PendingPayment tryParsePayment(String chatLine, ModConfig config) {
		ensureCompiled(config);
		Matcher m = paymentPattern.matcher(chatLine.trim());
		if (!m.matches()) return null;
		String player = m.group("player");
		double amount = AmountUtil.parse(m.group("amount"));
		if (amount <= 0) return null;
		return new PendingPayment(player, amount, System.currentTimeMillis());
	}

	/** Returns the parsed amount for an auction win/sale line, or null if it doesn't match. */
	public Double tryParseAuction(String chatLine, ModConfig config) {
		ensureCompiled(config);
		Matcher m = auctionPattern.matcher(chatLine.trim());
		if (!m.matches()) return null;
		String group = m.group("amount");
		if (group == null) return null;
		double amount = AmountUtil.parse(group);
		return amount > 0 ? amount : null;
	}

	private void ensureCompiled(ModConfig config) {
		if (paymentPattern == null || !config.paymentRegex.equals(compiledFromPaymentRegex)) {
			paymentPattern = Pattern.compile(config.paymentRegex);
			compiledFromPaymentRegex = config.paymentRegex;
		}
		if (auctionPattern == null || !config.auctionRegex.equals(compiledFromAuctionRegex)) {
			auctionPattern = Pattern.compile(config.auctionRegex);
			compiledFromAuctionRegex = config.auctionRegex;
		}
	}
}
