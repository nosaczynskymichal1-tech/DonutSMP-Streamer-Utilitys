package com.streamer.earningstracker.client.config;

import com.streamer.earningstracker.client.EarningsTrackerClient;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.text.Text;

/**
 * Opened with Right Shift (default) or from Mod Menu. Lets you edit the
 * donate target/amount, payout cap, cooldown, and goal without hand-editing
 * the JSON config file.
 */
public class SettingsScreen extends Screen {
	private final Screen parent;
	private TextFieldWidget donateTargetField;
	private TextFieldWidget donateAmountField;
	private TextFieldWidget capField;
	private TextFieldWidget cooldownField;
	private TextFieldWidget goalField;

	public SettingsScreen(Screen parent) {
		super(Text.literal("Earnings Tracker Settings"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		ModConfig cfg = EarningsTrackerClient.CONFIG;
		int cx = this.width / 2;
		int y = this.height / 2 - 70;

		donateTargetField = addField(cx, y, "Donate target player", cfg.donateTarget);
		y += 24;
		donateAmountField = addField(cx, y, "Donate amount", String.valueOf((long) cfg.donateAmount));
		y += 24;
		capField = addField(cx, y, "Max payout per action", String.valueOf((long) cfg.maxPayoutPerAction));
		y += 24;
		cooldownField = addField(cx, y, "Cooldown (seconds)", String.valueOf(cfg.cooldownSeconds));
		y += 24;
		goalField = addField(cx, y, "Goal amount (0 = hidden)", String.valueOf((long) cfg.goalAmount));
		y += 30;

		this.addDrawableChild(ButtonWidget.builder(Text.literal("Save"), b -> saveAndClose())
				.dimensions(cx - 100, y, 95, 20).build());
		this.addDrawableChild(ButtonWidget.builder(Text.literal("Cancel"), b -> close())
				.dimensions(cx + 5, y, 95, 20).build());
	}

	private TextFieldWidget addField(int cx, int y, String label, String initial) {
		TextFieldWidget field = new TextFieldWidget(this.textRenderer, cx - 100, y, 200, 20, Text.literal(label));
		field.setText(initial);
		field.setMaxLength(64);
		this.addDrawableChild(field);
		return field;
	}

	private void saveAndClose() {
		ModConfig cfg = EarningsTrackerClient.CONFIG;
		cfg.donateTarget = donateTargetField.getText().trim();
		cfg.donateAmount = parseOr(donateAmountField.getText(), cfg.donateAmount);
		cfg.maxPayoutPerAction = parseOr(capField.getText(), cfg.maxPayoutPerAction);
		cfg.cooldownSeconds = (int) parseOr(cooldownField.getText(), cfg.cooldownSeconds);
		cfg.goalAmount = parseOr(goalField.getText(), cfg.goalAmount);
		cfg.save();
		close();
	}

	private double parseOr(String text, double fallback) {
		try {
			return Double.parseDouble(text.trim());
		} catch (NumberFormatException e) {
			return fallback;
		}
	}

	@Override
	public void close() {
		if (this.client != null) this.client.setScreen(parent);
	}

	@Override
	public void render(net.minecraft.client.gui.DrawContext context, int mouseX, int mouseY, float delta) {
		this.renderBackground(context, mouseX, mouseY, delta);
		super.render(context, mouseX, mouseY, delta);
		context.drawCenteredTextWithShadow(this.textRenderer, this.title, this.width / 2, this.height / 2 - 95, 0xFFFFFF);
	}
}
